const { build } = require('esbuild');
build({
  entryPoints: ['server.ts'],
  bundle: true,
  platform: 'node',
  format: 'cjs',
  packages: 'external',
  outfile: 'server.cjs',
}).catch(() => process.exit(1));

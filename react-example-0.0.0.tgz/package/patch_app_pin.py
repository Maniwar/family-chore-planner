import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

# Fix childNote
content = content.replace("childNote: note,", "note: note,")

# Fix handleSetMemberPin
old_pin = r"""          onSuccess: \(newPin\) => \{
            handleSetMemberPin\(member\.id, newPin\);
            authenticateMember\(member\.id\);
            performClaim\(\);
          \},"""
new_pin = """          onSuccess: (newPin) => {
            const updatedMember = { ...member, pin: newPin };
            const updatedMembersList = members.map(m => m.id === member.id ? updatedMember : m);
            setMembers(updatedMembersList);
            saveMembers(updatedMembersList);
            const targetHhId = activeHousehold?.id || getCurrentHouseholdId();
            syncCompleteHouseholdToCloud(targetHhId, { version: activeHousehold?.version, members: updatedMembersList }).catch(() => {});
            authenticateMember(member.id);
            performClaim();
          },"""
content = re.sub(old_pin, new_pin, content)

with open('src/App.tsx', 'w') as f:
    f.write(content)

import json

with open('package.json', 'r') as f:
    data = json.load(f)

deps = data.get('dependencies', {})
dev_deps = data.get('devDependencies', {})

to_move = [
    'vite', '@vitejs/plugin-react', '@tailwindcss/vite', 'tailwindcss', 
    'autoprefixer', 'typescript', 'tsx', 'esbuild', 
    '@types/canvas-confetti', '@types/express', '@types/node', '@types/three'
]

for pkg in to_move:
    if pkg in deps:
        dev_deps[pkg] = deps.pop(pkg)

data['dependencies'] = deps
data['devDependencies'] = dev_deps

with open('package.json', 'w') as f:
    json.dump(data, f, indent=2)

import confetti from 'canvas-confetti';
import { 
  HouseholdMember, 
  Chore, 
  ChoreAssignmentLog, 
  RewardItem, 
  RewardClaim, 
  HouseholdInfo,
  HouseholdPenaltySettings,
  ChoreEvent,
  NudgeRecord
} from '../types';
import { INITIAL_MEMBERS, INITIAL_CHORES, generateSampleLogs, INITIAL_REWARDS, INITIAL_CLAIMS, getTodayDateString } from '../data/initialData';
import { calculateAge } from './age';
import { DEFAULT_PENALTY_SETTINGS, getISOWeekNumber } from './penaltyEngine';

export { getTodayDateString, DEFAULT_PENALTY_SETTINGS, getISOWeekNumber };

const STORAGE_KEYS = {
  MEMBERS: 'family_chores_members_v2',
  CHORES: 'family_chores_items_v2',
  LOGS: 'family_chores_logs_v2',
  REWARDS: 'family_chores_rewards_v2',
  CLAIMS: 'family_chores_claims_v2',
  ACTIVE_VIEW_MEMBER: 'family_chores_active_member_v2',
  MOM_MODE: 'family_chores_mom_mode_v2',
  HOUSEHOLD_INFO: 'family_chores_household_info_v1',
  PENALTY_SETTINGS: 'family_chores_penalty_settings_v1',
  EVENTS: 'family_chores_events_v1',
  NUDGES: 'family_chores_nudges_v1',
  DAILY_LAYOUT: 'family_chores_daily_layout_v1',
};

export const loadStoredDailyLayout = (): 'list' | 'grid' => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.DAILY_LAYOUT);
    if (saved === 'grid' || saved === 'list') {
      return saved;
    }
  } catch (e) {
    console.error('Failed to load daily layout preference', e);
  }
  return 'list';
};

export const saveDailyLayout = (layout: 'list' | 'grid'): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.DAILY_LAYOUT, layout);
  } catch (e) {
    console.error('Failed to save daily layout preference', e);
  }
};

export const DEFAULT_HOUSEHOLD_INFO: HouseholdInfo = {
  familyName: 'Our Family Home',
  houseAddressOrMotto: 'Clean spaces, happy smiles & teamwork! ✨',
};

export const loadStoredHouseholdInfo = (): HouseholdInfo => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.HOUSEHOLD_INFO);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error('Failed to load household info from localStorage', e);
  }
  return DEFAULT_HOUSEHOLD_INFO;
};

export const saveHouseholdInfo = (info: HouseholdInfo): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.HOUSEHOLD_INFO, JSON.stringify(info));
  } catch (e) {
    console.error('Failed to save household info', e);
  }
};

export const loadStoredMembers = (): HouseholdMember[] => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.MEMBERS);
    if (saved) {
      const parsed: HouseholdMember[] = JSON.parse(saved);
      // Dynamically calculate current ages from birth dates
      return parsed.map((m) => ({
        ...m,
        age: m.birthDate ? calculateAge(m.birthDate) : m.age,
      }));
    }
  } catch (e) {
    console.error('Failed to load members from localStorage', e);
  }
  return INITIAL_MEMBERS.map((m) => ({
    ...m,
    age: m.birthDate ? calculateAge(m.birthDate) : m.age,
  }));
};

export const saveMembers = (members: HouseholdMember[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  } catch (e) {
    console.error('Failed to save members', e);
  }
};

export const loadStoredChores = (): Chore[] => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.CHORES);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error('Failed to load chores from localStorage', e);
  }
  return INITIAL_CHORES;
};

export const saveChores = (chores: Chore[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.CHORES, JSON.stringify(chores));
  } catch (e) {
    console.error('Failed to save chores', e);
  }
};

export const sanitizeLogs = (logs: ChoreAssignmentLog[]): ChoreAssignmentLog[] => {
  if (!Array.isArray(logs)) return [];
  const today = getTodayDateString();
  const syntheticStaleIds = new Set([
    `log_${today}_chore_kitchen_unload_dw_mem_maya`,
    `log_${today}_chore_yard_water_mem_maya`,
    `log_${today}_chore_bed_maya_mem_maya`,
    `log_${today}_chore_kitchen_dining_table_mem_maya`,
  ]);
  return logs.filter(l => {
    if (syntheticStaleIds.has(l.id)) return false;
    // Removed date > today restriction so future pending checklists can sync
    return true;
  });
};

export const loadStoredLogs = (): ChoreAssignmentLog[] => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.LOGS);
    if (saved) {
      const parsed: ChoreAssignmentLog[] = JSON.parse(saved);
      const cleaned = sanitizeLogs(parsed);
      if (cleaned.length !== parsed.length) {
        saveLogs(cleaned);
      }
      return cleaned;
    }
  } catch (e) {
    console.error('Failed to load logs from localStorage', e);
  }
  return generateSampleLogs();
};

export const saveLogs = (logs: ChoreAssignmentLog[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs));
  } catch (e) {
    console.error('Failed to save logs', e);
  }
};

const LEGACY_REWARD_ID_MAP: Record<string, string> = {
  'rew_3': 'rew_cash_15',
  'rew_cash_10': 'rew_cash_15',
  'rew_4': 'rew_ice_cream',
};

export const mergeRewardsWithDefaults = (existingRewards: RewardItem[]): RewardItem[] => {
  if (!existingRewards || existingRewards.length === 0) return INITIAL_REWARDS;

  const seenDefaultIds = new Set<string>();
  const processedRewards: RewardItem[] = [];

  for (const r of existingRewards) {
    // 1. Direct ID match against latest catalog
    let defaultMatch = INITIAL_REWARDS.find(d => d.id === r.id);

    // 2. Check legacy ID alias map (e.g. rew_3 -> rew_cash_15, rew_4 -> rew_ice_cream)
    if (!defaultMatch && LEGACY_REWARD_ID_MAP[r.id]) {
      defaultMatch = INITIAL_REWARDS.find(d => d.id === LEGACY_REWARD_ID_MAP[r.id]);
    }

    // 3. Fallback fuzzy match for old cash allowance or default titles
    if (!defaultMatch) {
      const norm = (r.title || '').toLowerCase().trim();
      if ((r.category === 'allowance' || norm.includes('cash') || norm.includes('allowance')) && (norm.includes('15') || norm.includes('10'))) {
        defaultMatch = INITIAL_REWARDS.find(d => d.id === 'rew_cash_15');
      } else if ((r.category === 'allowance' || norm.includes('cash') || norm.includes('allowance')) && norm.includes('25')) {
        defaultMatch = INITIAL_REWARDS.find(d => d.id === 'rew_cash_25');
      } else if ((r.category === 'allowance' || norm.includes('cash') || norm.includes('allowance')) && norm.includes('50')) {
        defaultMatch = INITIAL_REWARDS.find(d => d.id === 'rew_cash_50');
      } else if ((r.category === 'allowance' || norm.includes('cash') || norm.includes('allowance') || norm.includes('jackpot')) && norm.includes('100')) {
        defaultMatch = INITIAL_REWARDS.find(d => d.id === 'rew_jackpot_100');
      } else if (norm.includes('ice cream parlor') || norm.includes('double scoop')) {
        defaultMatch = INITIAL_REWARDS.find(d => d.id === 'rew_ice_cream');
      }
    }

    if (defaultMatch) {
      // Prevent duplicate instances of the same canonical default reward
      if (seenDefaultIds.has(defaultMatch.id)) {
        continue;
      }
      seenDefaultIds.add(defaultMatch.id);

      // Upgrade existing item to calibrated Game Theory properties
      processedRewards.push({
        ...r,
        ...defaultMatch,
        id: defaultMatch.id,
        title: defaultMatch.title,
        pointCost: defaultMatch.pointCost,
        description: defaultMatch.description,
        realWorldValue: defaultMatch.realWorldValue,
        minLevel: defaultMatch.minLevel,
        rarity: defaultMatch.rarity,
        category: defaultMatch.category,
        cosmeticId: defaultMatch.cosmeticId,
        isJackpot: defaultMatch.isJackpot,
        saverBonus: defaultMatch.saverBonus,
      });
    } else {
      // Custom parent-created reward: preserve intact
      processedRewards.push(r);
    }
  }

  // Add any missing default catalog rewards
  for (const d of INITIAL_REWARDS) {
    if (!seenDefaultIds.has(d.id)) {
      processedRewards.push(d);
      seenDefaultIds.add(d.id);
    }
  }

  return processedRewards;
};

export const loadStoredRewards = (): RewardItem[] => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.REWARDS);
    if (saved) {
      const parsed: RewardItem[] = JSON.parse(saved);
      const merged = mergeRewardsWithDefaults(parsed);
      const mergedStr = JSON.stringify(merged);
      if (mergedStr !== saved) {
        localStorage.setItem(STORAGE_KEYS.REWARDS, mergedStr);
      }
      return merged;
    }
  } catch (e) {
    console.error('Failed to load rewards', e);
  }
  return INITIAL_REWARDS;
};

export const saveRewards = (rewards: RewardItem[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.REWARDS, JSON.stringify(rewards));
  } catch (e) {
    console.error('Failed to save rewards', e);
  }
};

export const loadStoredClaims = (): RewardClaim[] => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.CLAIMS);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error('Failed to load claims', e);
  }
  return INITIAL_CLAIMS;
};

export const saveClaims = (claims: RewardClaim[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.CLAIMS, JSON.stringify(claims));
  } catch (e) {
    console.error('Failed to save claims', e);
  }
};

export const loadStoredPenaltySettings = (): HouseholdPenaltySettings => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.PENALTY_SETTINGS);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error('Failed to load penalty settings from localStorage', e);
  }
  return DEFAULT_PENALTY_SETTINGS;
};

export const savePenaltySettings = (settings: HouseholdPenaltySettings): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.PENALTY_SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save penalty settings', e);
  }
};

export const generateSampleEvents = (): ChoreEvent[] => {
  const now = Date.now();
  const currentDate = new Date();
  const thisWeekNum = getISOWeekNumber(currentDate);
  const lastWeekDate = new Date(now - 7 * 24 * 3600 * 1000);
  const lastWeekNum = getISOWeekNumber(lastWeekDate);
  const currentYear = currentDate.getFullYear();
  const tomorrowDateStr = new Date(now + 24 * 3600 * 1000).toISOString().split('T')[0];

  return [
    {
      id: 'evt_w1',
      householdId: 'default',
      type: 'penalty_waived',
      memberId: 'mem_maya',
      memberName: 'Maya',
      choreId: 'chore_kitchen_unload_dw',
      choreTitle: 'Unload & Load Dishwasher & Handwash Delicate Items',
      reason: 'Doctor appointment and extra homework',
      weekNumber: thisWeekNum,
      year: currentYear,
      createdAt: new Date(now - 10 * 3600 * 1000).toISOString(),
    },
    {
      id: 'evt_w2',
      householdId: 'default',
      type: 'penalty_waived',
      memberId: 'mem_leo',
      memberName: 'Leo',
      choreId: 'chore_living_pillows_throws',
      choreTitle: 'Fluff Couch Pillows, Fold Throws & Clear Coffee Table',
      reason: 'Parent waived backlog for weekend family trip',
      weekNumber: thisWeekNum,
      year: currentYear,
      createdAt: new Date(now - 22 * 3600 * 1000).toISOString(),
    },
    {
      id: 'evt_w3',
      householdId: 'default',
      type: 'penalty_waived',
      memberId: 'mem_maya',
      memberName: 'Maya',
      choreId: 'chore_dining_set_table',
      choreTitle: 'Set Table for Family Meals & Clear Table Afterward',
      reason: 'Sick with flu on Wednesday',
      weekNumber: lastWeekNum,
      year: currentYear,
      createdAt: new Date(now - 4 * 24 * 3600 * 1000).toISOString(),
    },
    {
      id: 'evt_w4',
      householdId: 'default',
      type: 'penalty_waived',
      memberId: 'mem_emma',
      memberName: 'Emma',
      choreId: 'chore_bath_toilets',
      choreTitle: 'Deep Clean & Sanitize Bathroom Sinks, Toilets & Mirrors',
      reason: 'College entrance practice exam weekend',
      weekNumber: lastWeekNum,
      year: currentYear,
      createdAt: new Date(now - 6 * 24 * 3600 * 1000).toISOString(),
    },
    {
      id: 'evt_1',
      householdId: 'default',
      type: 'penalty_applied',
      memberId: 'mem_jordan',
      memberName: 'Jordan',
      choreId: 'chore_bath_tub_shower',
      choreTitle: 'Scrub Bathtub, Shower Walls & Chrome Fixtures',
      pointsBefore: 120,
      pointsAfter: 115,
      pointsDelta: -5,
      reason: '3 days late lateness deduction (25%)',
      tier: 3,
      weekNumber: thisWeekNum,
      year: currentYear,
      createdAt: new Date(now - 36 * 3600 * 1000).toISOString(),
    },
    {
      id: 'evt_2',
      householdId: 'default',
      type: 'nudge_sent',
      memberId: 'mem_jordan',
      memberName: 'Jordan',
      choreId: 'chore_bath_tub_shower',
      choreTitle: 'Scrub Bathtub, Shower Walls & Chrome Fixtures',
      reason: 'Mom: Please wrap this up before dinner tonight!',
      weekNumber: thisWeekNum,
      year: currentYear,
      createdAt: new Date(now - 12 * 3600 * 1000).toISOString(),
    },
    {
      id: 'evt_3',
      householdId: 'default',
      type: 'due_extended',
      memberId: 'mem_emma',
      memberName: 'Emma',
      choreId: 'chore_kitchen_pots_pans',
      choreTitle: 'Handwash Big Pots, Pans & Baking Sheets',
      reason: 'Extended by 1 day for exam study',
      extendedToDate: tomorrowDateStr,
      weekNumber: thisWeekNum,
      year: currentYear,
      createdAt: new Date(now - 48 * 3600 * 1000).toISOString(),
    },
  ];
};

export const loadStoredEvents = (): ChoreEvent[] => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.EVENTS);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error('Failed to load events from localStorage', e);
  }
  return generateSampleEvents();
};

export const saveEvents = (events: ChoreEvent[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  } catch (e) {
    console.error('Failed to save events', e);
  }
};

export const loadStoredNudges = (): NudgeRecord[] => {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.NUDGES);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error('Failed to load nudges from localStorage', e);
  }
  return [
    {
      id: 'nudge_1',
      householdId: 'default',
      memberId: 'jordan',
      memberName: 'Jordan',
      senderRole: 'parent',
      senderName: 'Mom',
      message: 'Hey Jordan, please wrap up the bathroom sinks before tonight to keep your points! ⭐',
      choreId: 'jordan_1',
      choreTitle: 'Scrub Upstairs Kids Bathroom Sinks & Mirrors',
      createdAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString(),
      acknowledged: false,
    }
  ];
};

export const saveNudges = (nudges: NudgeRecord[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.NUDGES, JSON.stringify(nudges));
  } catch (e) {
    console.error('Failed to save nudges', e);
  }
};

export const resetAllToDemo = (): {
  members: HouseholdMember[];
  chores: Chore[];
  logs: ChoreAssignmentLog[];
  rewards: RewardItem[];
  claims: RewardClaim[];
  penaltySettings: HouseholdPenaltySettings;
  events: ChoreEvent[];
  nudges: NudgeRecord[];
} => {
  const members = INITIAL_MEMBERS;
  const chores = INITIAL_CHORES;
  const logs = generateSampleLogs();
  const rewards = INITIAL_REWARDS;
  const claims = INITIAL_CLAIMS;
  const penaltySettings = DEFAULT_PENALTY_SETTINGS;
  const events = generateSampleEvents();
  const nudges = loadStoredNudges();

  saveMembers(members);
  saveChores(chores);
  saveLogs(logs);
  saveRewards(rewards);
  saveClaims(claims);
  savePenaltySettings(penaltySettings);
  saveEvents(events);
  saveNudges(nudges);

  return { members, chores, logs, rewards, claims, penaltySettings, events, nudges };
};

// Date helpers
export const parseLocalDate = (dateVal: any): Date => {
  const now = new Date();
  if (!dateVal) return now;
  if (dateVal instanceof Date) {
    return isNaN(dateVal.getTime()) ? now : dateVal;
  }
  let str = '';
  if (typeof dateVal === 'string') {
    str = dateVal.trim();
  } else if (typeof dateVal === 'number' && !isNaN(dateVal)) {
    const d = new Date(dateVal);
    return isNaN(d.getTime()) ? now : d;
  } else if (typeof dateVal === 'object' && dateVal !== null) {
    const candidate = dateVal.date || dateVal.originalDueDate || dateVal.extendedDueDate || dateVal.completedAt || dateVal.createdAt || dateVal.timestamp;
    if (candidate instanceof Date) return isNaN(candidate.getTime()) ? now : candidate;
    str = typeof candidate === 'string' ? candidate.trim() : (candidate ? String(candidate).trim() : '');
  } else {
    str = String(dateVal).trim();
  }
  if (!str) return now;
  if (str.includes('T')) {
    str = str.split('T')[0];
  }
  const parts = str.split('-').map(Number);
  const year = !isNaN(parts[0]) && parts[0] > 1900 ? parts[0] : now.getFullYear();
  const month = !isNaN(parts[1]) && parts[1] >= 1 ? parts[1] - 1 : now.getMonth();
  const day = !isNaN(parts[2]) && parts[2] >= 1 ? parts[2] : now.getDate();
  return new Date(year, month, day, 12, 0, 0);
};

export const formatDisplayDate = (dateStr: any): string => {
  if (!dateStr) return '';
  let str = '';
  if (typeof dateStr === 'string') {
    str = dateStr.trim();
  } else if (dateStr instanceof Date) {
    if (isNaN(dateStr.getTime())) return '';
    str = dateStr.toISOString().split('T')[0];
  } else if (typeof dateStr === 'number') {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    str = d.toISOString().split('T')[0];
  } else if (typeof dateStr === 'object' && dateStr !== null) {
    const candidate = dateStr.date || dateStr.originalDueDate || dateStr.extendedDueDate || dateStr.completedAt;
    str = typeof candidate === 'string' ? candidate.trim() : (candidate ? String(candidate).trim() : '');
  } else {
    str = String(dateStr).trim();
  }
  if (!str) return '';
  if (str.includes('T')) {
    str = str.split('T')[0];
  }
  const date = parseLocalDate(str);
  if (isNaN(date.getTime())) return 'Recent';
  const today = getTodayDateString();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = `${tomorrow.getFullYear()}-${String(tomorrow.getMonth() + 1).padStart(2, '0')}-${String(tomorrow.getDate()).padStart(2, '0')}`;

  const options: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric' };
  const formatted = date.toLocaleDateString(undefined, options);
  if (formatted === 'Invalid Date') return 'Recent';

  if (str === today) return `Today, ${formatted}`;
  if (str === yesterdayStr) return `Yesterday, ${formatted}`;
  if (str === tomorrowStr) return `Tomorrow, ${formatted}`;
  return formatted;
};

export const formatTimeDisplay = (timeStr?: string, timeOfDay?: string): string => {
  if (timeOfDay === 'anytime') {
    return 'Anytime';
  }
  if (timeStr && timeStr.includes(':') && timeOfDay !== 'anytime') {
    const [hours, minutes] = timeStr.split(':').map(Number);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const h12 = hours % 12 || 12;
    return `${h12}:${String(minutes).padStart(2, '0')} ${ampm}`;
  }
  if (timeOfDay) {
    switch (timeOfDay) {
      case 'morning': return 'Morning (by 9am)';
      case 'afternoon': return 'Afternoon (by 2pm)';
      case 'evening': return 'Evening (by 6pm)';
      case 'bedtime': return 'Bedtime (by 8pm)';
      case 'anytime': return 'Anytime';
      default: return 'Flexible time';
    }
  }
  return 'Anytime';
};

export const isChoreScheduledForDate = (chore: Chore, dateStr: string): boolean => {
  if (!chore.isActive) return false;
  const date = parseLocalDate(dateStr);
  const dayOfWeek = date.getDay(); // 0=Sunday, 6=Saturday

  // If dayAssignments is configured, check if this day is assigned or scheduled
  if (chore.dayAssignments && Object.keys(chore.dayAssignments).length > 0) {
    return Object.prototype.hasOwnProperty.call(chore.dayAssignments, dayOfWeek);
  }

  switch (chore.frequency) {
    case 'daily':
      return true;
    case 'weekdays':
      return dayOfWeek >= 1 && dayOfWeek <= 5;
    case 'weekends':
      return dayOfWeek === 0 || dayOfWeek === 6;
    case 'weekly':
    case 'custom_days':
      return Array.isArray(chore.scheduledDays) && chore.scheduledDays.includes(dayOfWeek);
    case 'as_needed':
      return true;
    default:
      return true;
  }
};

export const getChoreAssigneeForDate = (chore: Chore, dateStr: string): string => {
  const date = parseLocalDate(dateStr);
  const dayOfWeek = date.getDay(); // 0=Sunday..6=Saturday
  if (chore.dayAssignments && chore.dayAssignments[dayOfWeek]) {
    return chore.dayAssignments[dayOfWeek];
  }
  return chore.assignedMemberId || 'unassigned';
};

export const formatChoreScheduleDisplay = (chore: Chore): string => {
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // If dayAssignments are present with individual days
  if (chore.dayAssignments && Object.keys(chore.dayAssignments).length > 0) {
    const assignedDays = Object.keys(chore.dayAssignments).map(Number).sort((a, b) => a - b);
    if (assignedDays.length === 7) return 'Every Day (Rotating)';
    if (assignedDays.length === 5 && [1, 2, 3, 4, 5].every(d => assignedDays.includes(d))) return 'Weekdays (Rotating)';
    if (assignedDays.length === 2 && [0, 6].every(d => assignedDays.includes(d))) return 'Weekends (Rotating)';
    return assignedDays.map(d => dayNames[d]).join(', ');
  }

  switch (chore.frequency) {
    case 'daily':
      return 'Every Day';
    case 'weekdays':
      return 'Weekdays (Mon–Fri)';
    case 'weekends':
      return 'Weekends (Sat & Sun)';
    case 'as_needed':
      return 'As Needed';
    case 'weekly':
    case 'custom_days':
    default: {
      if (!chore.scheduledDays || chore.scheduledDays.length === 0) return 'Weekly';
      if (chore.scheduledDays.length === 7) return 'Every Day';
      if (chore.scheduledDays.length === 5 && [1, 2, 3, 4, 5].every(d => chore.scheduledDays.includes(d))) return 'Weekdays (Mon–Fri)';
      if (chore.scheduledDays.length === 2 && [0, 6].every(d => chore.scheduledDays.includes(d))) return 'Weekends (Sat & Sun)';
      const sorted = [...chore.scheduledDays].sort((a, b) => a - b);
      return sorted.map(d => dayNames[d]).join(', ');
    }
  }
};

export const getWeekDates = (centerDateStr: string): { dateStr: string; dayName: string; dayNumber: number; isToday: boolean; isSelected: boolean }[] => {
  const center = parseLocalDate(centerDateStr);
  const currentDayOfWeek = center.getDay(); // 0 is Sunday
  
  // Start on Sunday
  const startOfWeek = new Date(center);
  startOfWeek.setDate(center.getDate() - currentDayOfWeek);

  const days = [];
  const todayStr = getTodayDateString();

  for (let i = 0; i < 7; i++) {
    const d = new Date(startOfWeek);
    d.setDate(startOfWeek.getDate() + i);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const dStr = `${yyyy}-${mm}-${dd}`;

    const dayName = d.toLocaleDateString(undefined, { weekday: 'short' });
    const dayNumber = d.getDate();

    days.push({
      dateStr: dStr,
      dayName,
      dayNumber,
      isToday: dStr === todayStr,
      isSelected: dStr === centerDateStr,
    });
  }

  return days;
};

export const triggerConfettiCelebration = () => {
  try {
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#10B981', '#F59E0B', '#6366F1', '#EC4899', '#3B82F6'],
    });
  } catch (e) {
    // Graceful fallback
  }
};

export const triggerBigCelebration = () => {
  try {
    confetti({
      particleCount: 120,
      spread: 100,
      origin: { y: 0.6 },
      colors: ['#F59E0B', '#10B981', '#8B5CF6', '#F43F5E', '#06B6D4'],
    });
  } catch (e) {
    // Graceful fallback
  }
};
